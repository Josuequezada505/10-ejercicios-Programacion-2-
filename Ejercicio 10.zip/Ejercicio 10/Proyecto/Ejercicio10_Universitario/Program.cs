﻿using System;
using System.Windows.Forms;

namespace Ejercicio10_Universitario
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmUniversitario());
        }
    }
}