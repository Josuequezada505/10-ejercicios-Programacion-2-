﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Ejercicio10_Universitario.Entidades
{
    public class Carrera
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string NombreCarrera { get; set; }

        public virtual ICollection<Estudiante> Estudiantes { get; set; }

        public Carrera()
        {
            Estudiantes = new List<Estudiante>();
        }
    }
}