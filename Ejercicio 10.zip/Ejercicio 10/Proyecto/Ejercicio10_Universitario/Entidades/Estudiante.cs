﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Ejercicio10_Universitario.Entidades
{
    public class Estudiante
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Nombre { get; set; }

        public int Edad { get; set; }

        public int CarreraId { get; set; }

        [ForeignKey("CarreraId")]
        public virtual Carrera Carrera { get; set; }
    }
}