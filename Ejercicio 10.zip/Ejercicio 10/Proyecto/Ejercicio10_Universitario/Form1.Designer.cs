﻿namespace Ejercicio10_Universitario
{
    partial class FrmUniversitario
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.grpCarreras = new System.Windows.Forms.GroupBox();
            this.lblNombreCarrera = new System.Windows.Forms.Label();
            this.txtNombreCarrera = new System.Windows.Forms.TextBox();
            this.btnRegistrarCarrera = new System.Windows.Forms.Button();
            this.btnMostrarCarreras = new System.Windows.Forms.Button();
            this.dgvCarreras = new System.Windows.Forms.DataGridView();
            this.grpEstudiantes = new System.Windows.Forms.GroupBox();
            this.lblNombreEstudiante = new System.Windows.Forms.Label();
            this.txtNombreEstudiante = new System.Windows.Forms.TextBox();
            this.lblEdad = new System.Windows.Forms.Label();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.lblCarrera = new System.Windows.Forms.Label();
            this.cmbCarrera = new System.Windows.Forms.ComboBox();
            this.btnRegistrarEstudiante = new System.Windows.Forms.Button();
            this.grpConsulta = new System.Windows.Forms.GroupBox();
            this.lblFiltrarCarrera = new System.Windows.Forms.Label();
            this.cmbFiltroCarrera = new System.Windows.Forms.ComboBox();
            this.btnMostrarEstudiantes = new System.Windows.Forms.Button();
            this.btnFiltrarCarrera = new System.Windows.Forms.Button();
            this.dgvEstudiantes = new System.Windows.Forms.DataGridView();
            this.grpCarreras.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCarreras)).BeginInit();
            this.grpEstudiantes.SuspendLayout();
            this.grpConsulta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstudiantes)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCarreras
            // 
            this.grpCarreras.Controls.Add(this.lblNombreCarrera);
            this.grpCarreras.Controls.Add(this.txtNombreCarrera);
            this.grpCarreras.Controls.Add(this.btnRegistrarCarrera);
            this.grpCarreras.Controls.Add(this.btnMostrarCarreras);
            this.grpCarreras.Controls.Add(this.dgvCarreras);
            this.grpCarreras.Location = new System.Drawing.Point(20, 20);
            this.grpCarreras.Name = "grpCarreras";
            this.grpCarreras.Size = new System.Drawing.Size(980, 190);
            this.grpCarreras.TabIndex = 0;
            this.grpCarreras.TabStop = false;
            this.grpCarreras.Text = "Registro de carreras";
            // 
            // lblNombreCarrera
            // 
            this.lblNombreCarrera.AutoSize = true;
            this.lblNombreCarrera.Location = new System.Drawing.Point(25, 35);
            this.lblNombreCarrera.Name = "lblNombreCarrera";
            this.lblNombreCarrera.Size = new System.Drawing.Size(85, 13);
            this.lblNombreCarrera.TabIndex = 0;
            this.lblNombreCarrera.Text = "Nombre carrera";
            // 
            // txtNombreCarrera
            // 
            this.txtNombreCarrera.Location = new System.Drawing.Point(130, 32);
            this.txtNombreCarrera.Name = "txtNombreCarrera";
            this.txtNombreCarrera.Size = new System.Drawing.Size(280, 20);
            this.txtNombreCarrera.TabIndex = 1;
            // 
            // btnRegistrarCarrera
            // 
            this.btnRegistrarCarrera.Location = new System.Drawing.Point(440, 25);
            this.btnRegistrarCarrera.Name = "btnRegistrarCarrera";
            this.btnRegistrarCarrera.Size = new System.Drawing.Size(150, 35);
            this.btnRegistrarCarrera.TabIndex = 2;
            this.btnRegistrarCarrera.Text = "Registrar carrera";
            this.btnRegistrarCarrera.UseVisualStyleBackColor = true;
            this.btnRegistrarCarrera.Click += new System.EventHandler(this.btnRegistrarCarrera_Click);
            // 
            // btnMostrarCarreras
            // 
            this.btnMostrarCarreras.Location = new System.Drawing.Point(610, 25);
            this.btnMostrarCarreras.Name = "btnMostrarCarreras";
            this.btnMostrarCarreras.Size = new System.Drawing.Size(150, 35);
            this.btnMostrarCarreras.TabIndex = 3;
            this.btnMostrarCarreras.Text = "Mostrar carreras";
            this.btnMostrarCarreras.UseVisualStyleBackColor = true;
            this.btnMostrarCarreras.Click += new System.EventHandler(this.btnMostrarCarreras_Click);
            // 
            // dgvCarreras
            // 
            this.dgvCarreras.AllowUserToAddRows = false;
            this.dgvCarreras.AllowUserToDeleteRows = false;
            this.dgvCarreras.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCarreras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCarreras.Location = new System.Drawing.Point(25, 75);
            this.dgvCarreras.Name = "dgvCarreras";
            this.dgvCarreras.ReadOnly = true;
            this.dgvCarreras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCarreras.Size = new System.Drawing.Size(930, 95);
            this.dgvCarreras.TabIndex = 4;
            // 
            // grpEstudiantes
            // 
            this.grpEstudiantes.Controls.Add(this.lblNombreEstudiante);
            this.grpEstudiantes.Controls.Add(this.txtNombreEstudiante);
            this.grpEstudiantes.Controls.Add(this.lblEdad);
            this.grpEstudiantes.Controls.Add(this.txtEdad);
            this.grpEstudiantes.Controls.Add(this.lblCarrera);
            this.grpEstudiantes.Controls.Add(this.cmbCarrera);
            this.grpEstudiantes.Controls.Add(this.btnRegistrarEstudiante);
            this.grpEstudiantes.Location = new System.Drawing.Point(20, 225);
            this.grpEstudiantes.Name = "grpEstudiantes";
            this.grpEstudiantes.Size = new System.Drawing.Size(980, 100);
            this.grpEstudiantes.TabIndex = 1;
            this.grpEstudiantes.TabStop = false;
            this.grpEstudiantes.Text = "Registro de estudiantes";
            // 
            // lblNombreEstudiante
            // 
            this.lblNombreEstudiante.AutoSize = true;
            this.lblNombreEstudiante.Location = new System.Drawing.Point(25, 38);
            this.lblNombreEstudiante.Name = "lblNombreEstudiante";
            this.lblNombreEstudiante.Size = new System.Drawing.Size(44, 13);
            this.lblNombreEstudiante.TabIndex = 0;
            this.lblNombreEstudiante.Text = "Nombre";
            // 
            // txtNombreEstudiante
            // 
            this.txtNombreEstudiante.Location = new System.Drawing.Point(90, 35);
            this.txtNombreEstudiante.Name = "txtNombreEstudiante";
            this.txtNombreEstudiante.Size = new System.Drawing.Size(220, 20);
            this.txtNombreEstudiante.TabIndex = 1;
            // 
            // lblEdad
            // 
            this.lblEdad.AutoSize = true;
            this.lblEdad.Location = new System.Drawing.Point(335, 38);
            this.lblEdad.Name = "lblEdad";
            this.lblEdad.Size = new System.Drawing.Size(32, 13);
            this.lblEdad.TabIndex = 2;
            this.lblEdad.Text = "Edad";
            // 
            // txtEdad
            // 
            this.txtEdad.Location = new System.Drawing.Point(385, 35);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.Size = new System.Drawing.Size(80, 20);
            this.txtEdad.TabIndex = 3;
            // 
            // lblCarrera
            // 
            this.lblCarrera.AutoSize = true;
            this.lblCarrera.Location = new System.Drawing.Point(490, 38);
            this.lblCarrera.Name = "lblCarrera";
            this.lblCarrera.Size = new System.Drawing.Size(41, 13);
            this.lblCarrera.TabIndex = 4;
            this.lblCarrera.Text = "Carrera";
            // 
            // cmbCarrera
            // 
            this.cmbCarrera.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCarrera.FormattingEnabled = true;
            this.cmbCarrera.Location = new System.Drawing.Point(550, 35);
            this.cmbCarrera.Name = "cmbCarrera";
            this.cmbCarrera.Size = new System.Drawing.Size(220, 21);
            this.cmbCarrera.TabIndex = 5;
            // 
            // btnRegistrarEstudiante
            // 
            this.btnRegistrarEstudiante.Location = new System.Drawing.Point(800, 28);
            this.btnRegistrarEstudiante.Name = "btnRegistrarEstudiante";
            this.btnRegistrarEstudiante.Size = new System.Drawing.Size(150, 35);
            this.btnRegistrarEstudiante.TabIndex = 6;
            this.btnRegistrarEstudiante.Text = "Registrar estudiante";
            this.btnRegistrarEstudiante.UseVisualStyleBackColor = true;
            this.btnRegistrarEstudiante.Click += new System.EventHandler(this.btnRegistrarEstudiante_Click);
            // 
            // grpConsulta
            // 
            this.grpConsulta.Controls.Add(this.lblFiltrarCarrera);
            this.grpConsulta.Controls.Add(this.cmbFiltroCarrera);
            this.grpConsulta.Controls.Add(this.btnMostrarEstudiantes);
            this.grpConsulta.Controls.Add(this.btnFiltrarCarrera);
            this.grpConsulta.Controls.Add(this.dgvEstudiantes);
            this.grpConsulta.Location = new System.Drawing.Point(20, 340);
            this.grpConsulta.Name = "grpConsulta";
            this.grpConsulta.Size = new System.Drawing.Size(980, 250);
            this.grpConsulta.TabIndex = 2;
            this.grpConsulta.TabStop = false;
            this.grpConsulta.Text = "Consulta de estudiantes";
            // 
            // lblFiltrarCarrera
            // 
            this.lblFiltrarCarrera.AutoSize = true;
            this.lblFiltrarCarrera.Location = new System.Drawing.Point(25, 35);
            this.lblFiltrarCarrera.Name = "lblFiltrarCarrera";
            this.lblFiltrarCarrera.Size = new System.Drawing.Size(86, 13);
            this.lblFiltrarCarrera.TabIndex = 0;
            this.lblFiltrarCarrera.Text = "Filtrar por carrera";
            // 
            // cmbFiltroCarrera
            // 
            this.cmbFiltroCarrera.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFiltroCarrera.FormattingEnabled = true;
            this.cmbFiltroCarrera.Location = new System.Drawing.Point(130, 32);
            this.cmbFiltroCarrera.Name = "cmbFiltroCarrera";
            this.cmbFiltroCarrera.Size = new System.Drawing.Size(240, 21);
            this.cmbFiltroCarrera.TabIndex = 1;
            // 
            // btnMostrarEstudiantes
            // 
            this.btnMostrarEstudiantes.Location = new System.Drawing.Point(400, 25);
            this.btnMostrarEstudiantes.Name = "btnMostrarEstudiantes";
            this.btnMostrarEstudiantes.Size = new System.Drawing.Size(160, 35);
            this.btnMostrarEstudiantes.TabIndex = 2;
            this.btnMostrarEstudiantes.Text = "Mostrar estudiantes";
            this.btnMostrarEstudiantes.UseVisualStyleBackColor = true;
            this.btnMostrarEstudiantes.Click += new System.EventHandler(this.btnMostrarEstudiantes_Click);
            // 
            // btnFiltrarCarrera
            // 
            this.btnFiltrarCarrera.Location = new System.Drawing.Point(580, 25);
            this.btnFiltrarCarrera.Name = "btnFiltrarCarrera";
            this.btnFiltrarCarrera.Size = new System.Drawing.Size(160, 35);
            this.btnFiltrarCarrera.TabIndex = 3;
            this.btnFiltrarCarrera.Text = "Filtrar por carrera";
            this.btnFiltrarCarrera.UseVisualStyleBackColor = true;
            this.btnFiltrarCarrera.Click += new System.EventHandler(this.btnFiltrarCarrera_Click);
            // 
            // dgvEstudiantes
            // 
            this.dgvEstudiantes.AllowUserToAddRows = false;
            this.dgvEstudiantes.AllowUserToDeleteRows = false;
            this.dgvEstudiantes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEstudiantes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEstudiantes.Location = new System.Drawing.Point(25, 75);
            this.dgvEstudiantes.Name = "dgvEstudiantes";
            this.dgvEstudiantes.ReadOnly = true;
            this.dgvEstudiantes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEstudiantes.Size = new System.Drawing.Size(930, 155);
            this.dgvEstudiantes.TabIndex = 4;
            // 
            // FrmUniversitario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 610);
            this.Controls.Add(this.grpConsulta);
            this.Controls.Add(this.grpEstudiantes);
            this.Controls.Add(this.grpCarreras);
            this.Name = "FrmUniversitario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema Universitario";
            this.Load += new System.EventHandler(this.FrmUniversitario_Load);
            this.grpCarreras.ResumeLayout(false);
            this.grpCarreras.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCarreras)).EndInit();
            this.grpEstudiantes.ResumeLayout(false);
            this.grpEstudiantes.PerformLayout();
            this.grpConsulta.ResumeLayout(false);
            this.grpConsulta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstudiantes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCarreras;
        private System.Windows.Forms.Label lblNombreCarrera;
        private System.Windows.Forms.TextBox txtNombreCarrera;
        private System.Windows.Forms.Button btnRegistrarCarrera;
        private System.Windows.Forms.Button btnMostrarCarreras;
        private System.Windows.Forms.DataGridView dgvCarreras;
        private System.Windows.Forms.GroupBox grpEstudiantes;
        private System.Windows.Forms.Label lblNombreEstudiante;
        private System.Windows.Forms.TextBox txtNombreEstudiante;
        private System.Windows.Forms.Label lblEdad;
        private System.Windows.Forms.TextBox txtEdad;
        private System.Windows.Forms.Label lblCarrera;
        private System.Windows.Forms.ComboBox cmbCarrera;
        private System.Windows.Forms.Button btnRegistrarEstudiante;
        private System.Windows.Forms.GroupBox grpConsulta;
        private System.Windows.Forms.Label lblFiltrarCarrera;
        private System.Windows.Forms.ComboBox cmbFiltroCarrera;
        private System.Windows.Forms.Button btnMostrarEstudiantes;
        private System.Windows.Forms.Button btnFiltrarCarrera;
        private System.Windows.Forms.DataGridView dgvEstudiantes;
    }
}