﻿using System.Data.Entity;
using Ejercicio10_Universitario.Entidades;

namespace Ejercicio10_Universitario.Datos
{
    public class UniversidadContext : DbContext
    {
        public UniversidadContext() : base("name=ConexionUniversitario")
        {
        }

        public DbSet<Carrera> Carreras { get; set; }
        public DbSet<Estudiante> Estudiantes { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Carrera>().ToTable("Carreras");
            modelBuilder.Entity<Estudiante>().ToTable("Estudiantes");

            modelBuilder.Entity<Carrera>()
                .HasMany(c => c.Estudiantes)
                .WithRequired(e => e.Carrera)
                .HasForeignKey(e => e.CarreraId);

            base.OnModelCreating(modelBuilder);
        }
    }
}