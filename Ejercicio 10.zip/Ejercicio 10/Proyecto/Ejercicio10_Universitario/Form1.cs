﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using Ejercicio10_Universitario.Datos;
using Ejercicio10_Universitario.Entidades;

namespace Ejercicio10_Universitario
{
    public partial class FrmUniversitario : Form
    {
        public FrmUniversitario()
        {
            InitializeComponent();
        }

        private void FrmUniversitario_Load(object sender, EventArgs e)
        {
            Database.SetInitializer(new CreateDatabaseIfNotExists<UniversidadContext>());

            CargarCarrerasCombo();
            MostrarCarreras();
            MostrarEstudiantes();
        }

        private void LimpiarCarrera()
        {
            txtNombreCarrera.Clear();
            txtNombreCarrera.Focus();
        }

        private void LimpiarEstudiante()
        {
            txtNombreEstudiante.Clear();
            txtEdad.Clear();

            if (cmbCarrera.Items.Count > 0)
            {
                cmbCarrera.SelectedIndex = 0;
            }

            txtNombreEstudiante.Focus();
        }

        private void CargarCarrerasCombo()
        {
            using (UniversidadContext db = new UniversidadContext())
            {
                var listaCarreras = db.Carreras
                    .OrderBy(carrera => carrera.NombreCarrera)
                    .ToList();

                cmbCarrera.DataSource = null;
                cmbCarrera.DataSource = listaCarreras;
                cmbCarrera.DisplayMember = "NombreCarrera";
                cmbCarrera.ValueMember = "Id";

                var listaCarrerasFiltro = db.Carreras
                    .OrderBy(carrera => carrera.NombreCarrera)
                    .ToList();

                cmbFiltroCarrera.DataSource = null;
                cmbFiltroCarrera.DataSource = listaCarrerasFiltro;
                cmbFiltroCarrera.DisplayMember = "NombreCarrera";
                cmbFiltroCarrera.ValueMember = "Id";
            }
        }

        private void MostrarCarreras()
        {
            using (UniversidadContext db = new UniversidadContext())
            {
                var carreras = db.Carreras
                    .Select(carrera => new
                    {
                        carrera.Id,
                        carrera.NombreCarrera
                    })
                    .OrderBy(carrera => carrera.NombreCarrera)
                    .ToList();

                dgvCarreras.DataSource = carreras;
            }
        }

        private void MostrarEstudiantes()
        {
            using (UniversidadContext db = new UniversidadContext())
            {
                var estudiantes = db.Estudiantes
                    .Select(estudiante => new
                    {
                        estudiante.Id,
                        estudiante.Nombre,
                        estudiante.Edad,
                        Carrera = estudiante.Carrera.NombreCarrera
                    })
                    .OrderBy(estudiante => estudiante.Nombre)
                    .ToList();

                dgvEstudiantes.DataSource = estudiantes;
            }
        }

        private void btnRegistrarCarrera_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreCarrera.Text))
            {
                MessageBox.Show("Debe ingresar el nombre de la carrera.");
                txtNombreCarrera.Focus();
                return;
            }

            using (UniversidadContext db = new UniversidadContext())
            {
                string nombreCarrera = txtNombreCarrera.Text.Trim();

                bool existe = db.Carreras.Any(carrera => carrera.NombreCarrera == nombreCarrera);

                if (existe)
                {
                    MessageBox.Show("La carrera ya está registrada.");
                    txtNombreCarrera.Focus();
                    return;
                }

                Carrera nuevaCarrera = new Carrera
                {
                    NombreCarrera = nombreCarrera
                };

                db.Carreras.Add(nuevaCarrera);
                db.SaveChanges();
            }

            MessageBox.Show("Carrera registrada correctamente.");

            LimpiarCarrera();
            CargarCarrerasCombo();
            MostrarCarreras();
        }

        private void btnMostrarCarreras_Click(object sender, EventArgs e)
        {
            MostrarCarreras();
        }

        private void btnRegistrarEstudiante_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreEstudiante.Text))
            {
                MessageBox.Show("Debe ingresar el nombre del estudiante.");
                txtNombreEstudiante.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtEdad.Text))
            {
                MessageBox.Show("Debe ingresar la edad del estudiante.");
                txtEdad.Focus();
                return;
            }

            if (!int.TryParse(txtEdad.Text, out int edad))
            {
                MessageBox.Show("La edad debe ser un número entero.");
                txtEdad.Focus();
                return;
            }

            if (edad <= 0)
            {
                MessageBox.Show("La edad debe ser mayor que cero.");
                txtEdad.Focus();
                return;
            }

            if (cmbCarrera.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar una carrera.");
                cmbCarrera.Focus();
                return;
            }

            int carreraId = Convert.ToInt32(cmbCarrera.SelectedValue);

            using (UniversidadContext db = new UniversidadContext())
            {
                Estudiante nuevoEstudiante = new Estudiante
                {
                    Nombre = txtNombreEstudiante.Text.Trim(),
                    Edad = edad,
                    CarreraId = carreraId
                };

                db.Estudiantes.Add(nuevoEstudiante);
                db.SaveChanges();
            }

            MessageBox.Show("Estudiante registrado correctamente.");

            LimpiarEstudiante();
            MostrarEstudiantes();
        }

        private void btnMostrarEstudiantes_Click(object sender, EventArgs e)
        {
            MostrarEstudiantes();
        }

        private void btnFiltrarCarrera_Click(object sender, EventArgs e)
        {
            if (cmbFiltroCarrera.SelectedValue == null)
            {
                MessageBox.Show("Debe seleccionar una carrera para filtrar.");
                cmbFiltroCarrera.Focus();
                return;
            }

            int carreraId = Convert.ToInt32(cmbFiltroCarrera.SelectedValue);

            using (UniversidadContext db = new UniversidadContext())
            {
                var estudiantes = db.Estudiantes
                    .Where(estudiante => estudiante.CarreraId == carreraId)
                    .Select(estudiante => new
                    {
                        estudiante.Id,
                        estudiante.Nombre,
                        estudiante.Edad,
                        Carrera = estudiante.Carrera.NombreCarrera
                    })
                    .OrderBy(estudiante => estudiante.Nombre)
                    .ToList();

                dgvEstudiantes.DataSource = estudiantes;
            }
        }
    }
}