CREATE DATABASE Ejercicio10UniversitarioDB;
GO

USE Ejercicio10UniversitarioDB;
GO

CREATE TABLE Carreras
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    NombreCarrera NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE Estudiantes
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100) NOT NULL,
    Edad INT NOT NULL,
    CarreraId INT NOT NULL,
    CONSTRAINT FK_Estudiantes_Carreras
    FOREIGN KEY (CarreraId) REFERENCES Carreras(Id)
);
GO