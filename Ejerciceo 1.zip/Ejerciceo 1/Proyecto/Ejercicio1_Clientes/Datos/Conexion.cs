﻿using System.Data.SqlClient;

namespace Ejercicio1_Clientes.Datos
{
    public class Conexion
    {
        public static string Cadena = @"Data Source=.\MSSQLSERVER1;Initial Catalog=Ejercicio1ClientesDB;Integrated Security=True;TrustServerCertificate=True;";
    }
}