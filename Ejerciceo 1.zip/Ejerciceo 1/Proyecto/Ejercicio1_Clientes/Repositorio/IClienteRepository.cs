﻿using System.Collections.Generic;
using Ejercicio1_Clientes.Entidades;

namespace Ejercicio1_Clientes.Repositorio
{
    public interface IClienteRepository
    {
        void Guardar(Cliente cliente);
        List<Cliente> MostrarTodos();
        void Eliminar(int id);
    }
}