﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Ejercicio1_Clientes.Datos;
using Ejercicio1_Clientes.Entidades;

namespace Ejercicio1_Clientes.Repositorio
{
    public class ClienteRepository : IClienteRepository
    {
        public void Guardar(Cliente cliente)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "INSERT INTO Clientes (Nombre, Telefono, Correo) VALUES (@Nombre, @Telefono, @Correo)";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                comando.Parameters.AddWithValue("@Telefono", cliente.Telefono);
                comando.Parameters.AddWithValue("@Correo", cliente.Correo);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public List<Cliente> MostrarTodos()
        {
            List<Cliente> lista = new List<Cliente>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Nombre, Telefono, Correo FROM Clientes";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Cliente
                    {
                        Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        Telefono = reader["Telefono"].ToString(),
                        Correo = reader["Correo"].ToString()
                    });
                }
            }

            return lista;
        }

        public void Eliminar(int id)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "DELETE FROM Clientes WHERE Id = @Id";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }
    }
}