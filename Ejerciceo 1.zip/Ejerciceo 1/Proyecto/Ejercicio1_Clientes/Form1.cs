﻿using System;
using System.Windows.Forms;
using Ejercicio1_Clientes.Entidades;
using Ejercicio1_Clientes.Repositorio;

namespace Ejercicio1_Clientes
{
    public partial class FrmClientes : Form
    {
        private readonly IClienteRepository _repositorio;

        public FrmClientes()
        {
            InitializeComponent();
            _repositorio = new ClienteRepository();
        }

        private void FrmClientes_Load(object sender, EventArgs e)
        {
            // Este método queda vacío.
            // Se agrega porque el diseñador lo está llamando.
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtNombre.Focus();
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Debe ingresar el nombre del cliente.");
                txtNombre.Focus();
                return false;
            }

            foreach (char letra in txtNombre.Text)
            {
                if (!char.IsLetter(letra) && !char.IsWhiteSpace(letra))
                {
                    MessageBox.Show("El nombre solo debe contener letras.");
                    txtNombre.Focus();
                    return false;
                }
            }

            if (string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("Debe ingresar el teléfono del cliente.");
                txtTelefono.Focus();
                return false;
            }

            foreach (char numero in txtTelefono.Text)
            {
                if (!char.IsDigit(numero))
                {
                    MessageBox.Show("El teléfono solo debe contener números.");
                    txtTelefono.Focus();
                    return false;
                }
            }

            if (string.IsNullOrWhiteSpace(txtCorreo.Text))
            {
                MessageBox.Show("Debe ingresar el correo del cliente.");
                txtCorreo.Focus();
                return false;
            }

            if (!txtCorreo.Text.Contains("@") || !txtCorreo.Text.Contains("."))
            {
                MessageBox.Show("Debe ingresar un correo válido.");
                txtCorreo.Focus();
                return false;
            }

            return true;
        }

        private void CargarClientes()
        {
            dgvClientes.DataSource = null;
            dgvClientes.DataSource = _repositorio.MostrarTodos();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                return;
            }

            Cliente cliente = new Cliente
            {
                Nombre = txtNombre.Text.Trim(),
                Telefono = txtTelefono.Text.Trim(),
                Correo = txtCorreo.Text.Trim()
            };

            _repositorio.Guardar(cliente);

            MessageBox.Show("Cliente guardado correctamente.");

            CargarClientes();
            LimpiarCampos();
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            CargarClientes();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvClientes.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar un cliente para eliminar.");
                return;
            }

            if (dgvClientes.CurrentRow.Cells["Id"].Value == null)
            {
                MessageBox.Show("Debe seleccionar un cliente válido.");
                return;
            }

            int id = Convert.ToInt32(dgvClientes.CurrentRow.Cells["Id"].Value);

            DialogResult respuesta = MessageBox.Show(
                "¿Está seguro que desea eliminar este cliente?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta == DialogResult.Yes)
            {
                _repositorio.Eliminar(id);
                MessageBox.Show("Cliente eliminado correctamente.");
                CargarClientes();
            }
        }
    }
}