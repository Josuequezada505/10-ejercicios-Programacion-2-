CREATE DATABASE Ejercicio5InventarioDB;
GO

USE Ejercicio5InventarioDB;
GO

CREATE TABLE Inventario
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Producto NVARCHAR(100) NOT NULL,
    Categoria NVARCHAR(100) NOT NULL,
    Cantidad INT NOT NULL,
    PrecioCompra DECIMAL(18,2) NOT NULL
);
GO