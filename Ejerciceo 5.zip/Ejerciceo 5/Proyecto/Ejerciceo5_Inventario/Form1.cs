﻿using System;
using System.Windows.Forms;
using Ejercicio5_Inventario.Entidades;
using Ejercicio5_Inventario.Repositorio;

namespace Ejercicio5_Inventario
{
    public partial class FrmProductos : Form
    {
        private readonly IInventarioRepository _repositorio;

        public FrmProductos()
        {
            InitializeComponent();
            _repositorio = new InventarioRepository();
        }

        private void FrmProductos_Load(object sender, EventArgs e)
        {
            // Este método queda vacío.
            // Se agrega porque el diseñador lo está llamando.
        }

        private void LimpiarCampos()
        {
            txtProducto.Clear();
            txtCategoria.Clear();
            txtCantidad.Clear();
            txtPrecioCompra.Clear();
            txtProducto.Focus();
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtProducto.Text))
            {
                MessageBox.Show("Debe ingresar el producto.");
                txtProducto.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtCategoria.Text))
            {
                MessageBox.Show("Debe ingresar la categoría.");
                txtCategoria.Focus();
                return false;
            }

            if (!int.TryParse(txtCantidad.Text, out int cantidad))
            {
                MessageBox.Show("La cantidad debe ser un número entero.");
                txtCantidad.Focus();
                return false;
            }

            if (cantidad < 0)
            {
                MessageBox.Show("La cantidad no puede ser negativa.");
                txtCantidad.Focus();
                return false;
            }

            if (!decimal.TryParse(txtPrecioCompra.Text, out decimal precioCompra))
            {
                MessageBox.Show("El precio de compra debe ser un número válido.");
                txtPrecioCompra.Focus();
                return false;
            }

            if (precioCompra < 0)
            {
                MessageBox.Show("El precio de compra no puede ser negativo.");
                txtPrecioCompra.Focus();
                return false;
            }

            return true;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                return;
            }

            Inventario inventario = new Inventario
            {
                Producto = txtProducto.Text.Trim(),
                Categoria = txtCategoria.Text.Trim(),
                Cantidad = int.Parse(txtCantidad.Text),
                PrecioCompra = decimal.Parse(txtPrecioCompra.Text)
            };

            _repositorio.Registrar(inventario);

            MessageBox.Show("Producto registrado correctamente.");

            dgvProductos.DataSource = null;
            dgvProductos.DataSource = _repositorio.MostrarTodos();

            LimpiarCampos();
        }

        private void btnMostrarTodo_Click(object sender, EventArgs e)
        {
            dgvProductos.DataSource = null;
            dgvProductos.DataSource = _repositorio.MostrarTodos();
        }

        private void btnStockBajo_Click(object sender, EventArgs e)
        {
            
            dgvProductos.DataSource = null;
            dgvProductos.DataSource = _repositorio.MostrarStockBajo();
        }

        private void btnValorTotal_Click(object sender, EventArgs e)
        {
            decimal total = _repositorio.ObtenerValorTotal();

            MessageBox.Show("El valor total del inventario es: C$ " + total.ToString("N2"));
        }
    }
}