﻿namespace Ejercicio5_Inventario.Entidades
{
    public class Inventario
    {
        public int Id { get; set; }
        public string Producto { get; set; }
        public string Categoria { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioCompra { get; set; }
    }
}