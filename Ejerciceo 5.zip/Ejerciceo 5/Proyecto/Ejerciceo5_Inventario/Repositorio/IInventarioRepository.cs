﻿using System.Collections.Generic;
using Ejercicio5_Inventario.Entidades;

namespace Ejercicio5_Inventario.Repositorio
{
    public interface IInventarioRepository
    {
        void Registrar(Inventario inventario);
        List<Inventario> MostrarTodos();
        List<Inventario> MostrarStockBajo();
        decimal ObtenerValorTotal();
    }
}