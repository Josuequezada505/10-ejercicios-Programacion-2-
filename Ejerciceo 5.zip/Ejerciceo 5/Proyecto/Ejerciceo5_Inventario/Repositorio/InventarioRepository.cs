﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Ejercicio5_Inventario.Datos;
using Ejercicio5_Inventario.Entidades;

namespace Ejercicio5_Inventario.Repositorio
{
    public class InventarioRepository : IInventarioRepository
    {
        public void Registrar(Inventario inventario)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "INSERT INTO Inventario (Producto, Categoria, Cantidad, PrecioCompra) VALUES (@Producto, @Categoria, @Cantidad, @PrecioCompra)";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Producto", inventario.Producto);
                comando.Parameters.AddWithValue("@Categoria", inventario.Categoria);
                comando.Parameters.AddWithValue("@Cantidad", inventario.Cantidad);
                comando.Parameters.AddWithValue("@PrecioCompra", inventario.PrecioCompra);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public List<Inventario> MostrarTodos()
        {
            List<Inventario> lista = new List<Inventario>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Producto, Categoria, Cantidad, PrecioCompra FROM Inventario";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Inventario
                    {
                        Id = (int)reader["Id"],
                        Producto = reader["Producto"].ToString(),
                        Categoria = reader["Categoria"].ToString(),
                        Cantidad = (int)reader["Cantidad"],
                        PrecioCompra = (decimal)reader["PrecioCompra"]
                    });
                }
            }

            return lista;
        }

        public List<Inventario> MostrarStockBajo()
        {
            List<Inventario> lista = new List<Inventario>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Producto, Categoria, Cantidad, PrecioCompra FROM Inventario WHERE Cantidad < 5";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Inventario
                    {
                        Id = (int)reader["Id"],
                        Producto = reader["Producto"].ToString(),
                        Categoria = reader["Categoria"].ToString(),
                        Cantidad = (int)reader["Cantidad"],
                        PrecioCompra = (decimal)reader["PrecioCompra"]
                    });
                }
            }

            return lista;
        }

        public decimal ObtenerValorTotal()
        {
            decimal total = 0;

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT ISNULL(SUM(Cantidad * PrecioCompra), 0) FROM Inventario";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                total = (decimal)comando.ExecuteScalar();
            }

            return total;
        }
    }
}