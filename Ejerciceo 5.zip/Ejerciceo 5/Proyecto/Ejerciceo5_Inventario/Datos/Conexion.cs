﻿using System.Data.SqlClient;

namespace Ejercicio5_Inventario.Datos
{
    public class Conexion
    {
        public static string Cadena = @"Data Source=.\MSSQLSERVER1;Initial Catalog=Ejercicio5InventarioDB;Integrated Security=True;TrustServerCertificate=True;";
    }
}