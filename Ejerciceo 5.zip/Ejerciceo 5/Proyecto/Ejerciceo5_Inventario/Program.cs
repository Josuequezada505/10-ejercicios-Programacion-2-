﻿using System;
using System.Windows.Forms;

namespace Ejercicio5_Inventario
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmProductos());
        }
    }
}