CREATE DATABASE Ejercicio6BibliotecaDB;
GO

USE Ejercicio6BibliotecaDB;
GO

CREATE TABLE Libros
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Titulo NVARCHAR(100) NOT NULL,
    Autor NVARCHAR(100) NOT NULL,
    AñoPublicacion INT NOT NULL,
    Disponible BIT NOT NULL
);
GO