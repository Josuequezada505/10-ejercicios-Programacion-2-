﻿using System.Collections.Generic;
using Ejercicio6_Biblioteca.Entidades;

namespace Ejercicio6_Biblioteca.Repositorio
{
    public interface ILibroRepository
    {
        void Registrar(Libro libro);
        void ActualizarDisponibilidad(int id, bool disponible);
        List<Libro> MostrarTodos();
        List<Libro> MostrarDisponibles();
        List<Libro> BuscarPorAutor(string autor);
    }
}