﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Ejercicio6_Biblioteca.Datos;
using Ejercicio6_Biblioteca.Entidades;

namespace Ejercicio6_Biblioteca.Repositorio
{
    public class LibroRepository : ILibroRepository
    {
        public void Registrar(Libro libro)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "INSERT INTO Libros (Titulo, Autor, AñoPublicacion, Disponible) VALUES (@Titulo, @Autor, @AnioPublicacion, @Disponible)";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Titulo", libro.Titulo);
                comando.Parameters.AddWithValue("@Autor", libro.Autor);
                comando.Parameters.AddWithValue("@AnioPublicacion", libro.AnioPublicacion);
                comando.Parameters.AddWithValue("@Disponible", libro.Disponible);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public void ActualizarDisponibilidad(int id, bool disponible)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "UPDATE Libros SET Disponible = @Disponible WHERE Id = @Id";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);
                comando.Parameters.AddWithValue("@Disponible", disponible);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public List<Libro> MostrarTodos()
        {
            List<Libro> lista = new List<Libro>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Titulo, Autor, AñoPublicacion, Disponible FROM Libros";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Libro
                    {
                        Id = (int)reader["Id"],
                        Titulo = reader["Titulo"].ToString(),
                        Autor = reader["Autor"].ToString(),
                        AnioPublicacion = (int)reader["AñoPublicacion"],
                        Disponible = (bool)reader["Disponible"]
                    });
                }
            }

            return lista;
        }

        public List<Libro> MostrarDisponibles()
        {
            List<Libro> lista = new List<Libro>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Titulo, Autor, AñoPublicacion, Disponible FROM Libros WHERE Disponible = 1";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Libro
                    {
                        Id = (int)reader["Id"],
                        Titulo = reader["Titulo"].ToString(),
                        Autor = reader["Autor"].ToString(),
                        AnioPublicacion = (int)reader["AñoPublicacion"],
                        Disponible = (bool)reader["Disponible"]
                    });
                }
            }

            return lista;
        }

        public List<Libro> BuscarPorAutor(string autor)
        {
            List<Libro> lista = new List<Libro>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Titulo, Autor, AñoPublicacion, Disponible FROM Libros WHERE Autor LIKE @Autor";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Autor", "%" + autor + "%");

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Libro
                    {
                        Id = (int)reader["Id"],
                        Titulo = reader["Titulo"].ToString(),
                        Autor = reader["Autor"].ToString(),
                        AnioPublicacion = (int)reader["AñoPublicacion"],
                        Disponible = (bool)reader["Disponible"]
                    });
                }
            }

            return lista;
        }
    }
}