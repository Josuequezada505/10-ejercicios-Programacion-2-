﻿using System;
using System.Windows.Forms;
using Ejercicio6_Biblioteca.Entidades;
using Ejercicio6_Biblioteca.Repositorio;

namespace Ejercicio6_Biblioteca
{
    public partial class FrmLibros : Form
    {
        private readonly ILibroRepository _repositorio;

        public FrmLibros()
        {
            InitializeComponent();
            _repositorio = new LibroRepository();
        }

        private void FrmLibros_Load(object sender, EventArgs e)
        {
        }

        private void LimpiarCampos()
        {
            txtTitulo.Clear();
            txtAutor.Clear();
            txtAnioPublicacion.Clear();
            txtBuscarAutor.Clear();
            chkDisponible.Checked = false;
            txtTitulo.Focus();
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtTitulo.Text))
            {
                MessageBox.Show("Debe ingresar el título del libro.");
                txtTitulo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtAutor.Text))
            {
                MessageBox.Show("Debe ingresar el autor del libro.");
                txtAutor.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtAnioPublicacion.Text))
            {
                MessageBox.Show("Debe ingresar el año de publicación.");
                txtAnioPublicacion.Focus();
                return false;
            }

            if (!int.TryParse(txtAnioPublicacion.Text, out int anio))
            {
                MessageBox.Show("El año de publicación debe ser un número entero.");
                txtAnioPublicacion.Focus();
                return false;
            }

            if (anio <= 0)
            {
                MessageBox.Show("El año de publicación debe ser mayor que cero.");
                txtAnioPublicacion.Focus();
                return false;
            }

            return true;
        }

        private void CargarLibros()
        {
            dgvLibros.DataSource = null;
            dgvLibros.DataSource = _repositorio.MostrarTodos();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;

            Libro libro = new Libro
            {
                Titulo = txtTitulo.Text.Trim(),
                Autor = txtAutor.Text.Trim(),
                AnioPublicacion = int.Parse(txtAnioPublicacion.Text),
                Disponible = chkDisponible.Checked
            };

            _repositorio.Registrar(libro);

            MessageBox.Show("Libro registrado correctamente.");

            CargarLibros();
            LimpiarCampos();
        }

        private void btnActualizarDisponibilidad_Click(object sender, EventArgs e)
        {
            if (dgvLibros.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar un libro para actualizar su disponibilidad.");
                return;
            }

            if (dgvLibros.CurrentRow.Cells["Id"].Value == null)
            {
                MessageBox.Show("Debe seleccionar un libro válido.");
                return;
            }

            int id = Convert.ToInt32(dgvLibros.CurrentRow.Cells["Id"].Value);
            bool disponible = chkDisponible.Checked;

            _repositorio.ActualizarDisponibilidad(id, disponible);

            MessageBox.Show("Disponibilidad actualizada correctamente.");

            CargarLibros();
            LimpiarCampos();
        }

        private void btnMostrarDisponibles_Click(object sender, EventArgs e)
        {
            dgvLibros.DataSource = null;
            dgvLibros.DataSource = _repositorio.MostrarDisponibles();
        }

        private void btnBuscarAutor_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBuscarAutor.Text))
            {
                MessageBox.Show("Debe ingresar el autor a buscar.");
                txtBuscarAutor.Focus();
                return;
            }

            dgvLibros.DataSource = null;
            dgvLibros.DataSource = _repositorio.BuscarPorAutor(txtBuscarAutor.Text.Trim());
        }

        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            CargarLibros();
        }

        private void dgvLibros_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvLibros.Rows[e.RowIndex];

                txtTitulo.Text = fila.Cells["Titulo"].Value.ToString();
                txtAutor.Text = fila.Cells["Autor"].Value.ToString();
                txtAnioPublicacion.Text = fila.Cells["AnioPublicacion"].Value.ToString();
                chkDisponible.Checked = Convert.ToBoolean(fila.Cells["Disponible"].Value);
            }
        }
    }
}