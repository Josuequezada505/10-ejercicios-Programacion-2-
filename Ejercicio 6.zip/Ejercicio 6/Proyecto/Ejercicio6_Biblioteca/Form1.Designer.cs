﻿namespace Ejercicio6_Biblioteca
{
    partial class FrmLibros
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblAutor = new System.Windows.Forms.Label();
            this.lblAnioPublicacion = new System.Windows.Forms.Label();
            this.lblBuscarAutor = new System.Windows.Forms.Label();
            this.txtTitulo = new System.Windows.Forms.TextBox();
            this.txtAutor = new System.Windows.Forms.TextBox();
            this.txtAnioPublicacion = new System.Windows.Forms.TextBox();
            this.txtBuscarAutor = new System.Windows.Forms.TextBox();
            this.chkDisponible = new System.Windows.Forms.CheckBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnActualizarDisponibilidad = new System.Windows.Forms.Button();
            this.btnMostrarDisponibles = new System.Windows.Forms.Button();
            this.btnBuscarAutor = new System.Windows.Forms.Button();
            this.btnMostrarTodos = new System.Windows.Forms.Button();
            this.dgvLibros = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLibros)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(57, 42);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(33, 13);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Titulo";
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Location = new System.Drawing.Point(58, 75);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(32, 13);
            this.lblAutor.TabIndex = 1;
            this.lblAutor.Text = "Autor";
            // 
            // lblAnioPublicacion
            // 
            this.lblAnioPublicacion.AutoSize = true;
            this.lblAnioPublicacion.Location = new System.Drawing.Point(44, 109);
            this.lblAnioPublicacion.Name = "lblAnioPublicacion";
            this.lblAnioPublicacion.Size = new System.Drawing.Size(83, 13);
            this.lblAnioPublicacion.TabIndex = 2;
            this.lblAnioPublicacion.Text = "Año publicacion";
            // 
            // lblBuscarAutor
            // 
            this.lblBuscarAutor.AutoSize = true;
            this.lblBuscarAutor.Location = new System.Drawing.Point(44, 205);
            this.lblBuscarAutor.Name = "lblBuscarAutor";
            this.lblBuscarAutor.Size = new System.Drawing.Size(85, 13);
            this.lblBuscarAutor.TabIndex = 3;
            this.lblBuscarAutor.Text = "Buscar por autor";
            // 
            // txtTitulo
            // 
            this.txtTitulo.Location = new System.Drawing.Point(153, 42);
            this.txtTitulo.Name = "txtTitulo";
            this.txtTitulo.Size = new System.Drawing.Size(175, 20);
            this.txtTitulo.TabIndex = 4;
            // 
            // txtAutor
            // 
            this.txtAutor.Location = new System.Drawing.Point(153, 68);
            this.txtAutor.Name = "txtAutor";
            this.txtAutor.Size = new System.Drawing.Size(175, 20);
            this.txtAutor.TabIndex = 5;
            // 
            // txtAnioPublicacion
            // 
            this.txtAnioPublicacion.Location = new System.Drawing.Point(153, 102);
            this.txtAnioPublicacion.Name = "txtAnioPublicacion";
            this.txtAnioPublicacion.Size = new System.Drawing.Size(175, 20);
            this.txtAnioPublicacion.TabIndex = 6;
            // 
            // txtBuscarAutor
            // 
            this.txtBuscarAutor.Location = new System.Drawing.Point(169, 205);
            this.txtBuscarAutor.Name = "txtBuscarAutor";
            this.txtBuscarAutor.Size = new System.Drawing.Size(159, 20);
            this.txtBuscarAutor.TabIndex = 7;
            // 
            // chkDisponible
            // 
            this.chkDisponible.AutoSize = true;
            this.chkDisponible.Location = new System.Drawing.Point(47, 141);
            this.chkDisponible.Name = "chkDisponible";
            this.chkDisponible.Size = new System.Drawing.Size(75, 17);
            this.chkDisponible.TabIndex = 8;
            this.chkDisponible.Text = "Disponible";
            this.chkDisponible.UseVisualStyleBackColor = true;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(419, 75);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(75, 57);
            this.btnRegistrar.TabIndex = 9;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // btnActualizarDisponibilidad
            // 
            this.btnActualizarDisponibilidad.Location = new System.Drawing.Point(560, 75);
            this.btnActualizarDisponibilidad.Name = "btnActualizarDisponibilidad";
            this.btnActualizarDisponibilidad.Size = new System.Drawing.Size(132, 54);
            this.btnActualizarDisponibilidad.TabIndex = 10;
            this.btnActualizarDisponibilidad.Text = "Actualizar disponibilidad";
            this.btnActualizarDisponibilidad.UseVisualStyleBackColor = true;
            this.btnActualizarDisponibilidad.Click += new System.EventHandler(this.btnActualizarDisponibilidad_Click);
            // 
            // btnMostrarDisponibles
            // 
            this.btnMostrarDisponibles.Location = new System.Drawing.Point(758, 75);
            this.btnMostrarDisponibles.Name = "btnMostrarDisponibles";
            this.btnMostrarDisponibles.Size = new System.Drawing.Size(108, 54);
            this.btnMostrarDisponibles.TabIndex = 11;
            this.btnMostrarDisponibles.Text = "Mostrar disponibles";
            this.btnMostrarDisponibles.UseVisualStyleBackColor = true;
            this.btnMostrarDisponibles.Click += new System.EventHandler(this.btnMostrarDisponibles_Click);
            // 
            // btnBuscarAutor
            // 
            this.btnBuscarAutor.Location = new System.Drawing.Point(497, 178);
            this.btnBuscarAutor.Name = "btnBuscarAutor";
            this.btnBuscarAutor.Size = new System.Drawing.Size(98, 66);
            this.btnBuscarAutor.TabIndex = 12;
            this.btnBuscarAutor.Text = "Buscar por autor";
            this.btnBuscarAutor.UseVisualStyleBackColor = true;
            this.btnBuscarAutor.Click += new System.EventHandler(this.btnBuscarAutor_Click);
            // 
            // btnMostrarTodos
            // 
            this.btnMostrarTodos.Location = new System.Drawing.Point(670, 178);
            this.btnMostrarTodos.Name = "btnMostrarTodos";
            this.btnMostrarTodos.Size = new System.Drawing.Size(87, 66);
            this.btnMostrarTodos.TabIndex = 13;
            this.btnMostrarTodos.Text = "Mostrar todos";
            this.btnMostrarTodos.UseVisualStyleBackColor = true;
            this.btnMostrarTodos.Click += new System.EventHandler(this.btnMostrarTodos_Click);
            // 
            // dgvLibros
            // 
            this.dgvLibros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLibros.Location = new System.Drawing.Point(60, 293);
            this.dgvLibros.Name = "dgvLibros";
            this.dgvLibros.Size = new System.Drawing.Size(806, 195);
            this.dgvLibros.TabIndex = 14;
            this.dgvLibros.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvLibros_CellClick);
            // 
            // FrmLibros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 521);
            this.Controls.Add(this.dgvLibros);
            this.Controls.Add(this.btnMostrarTodos);
            this.Controls.Add(this.btnBuscarAutor);
            this.Controls.Add(this.btnMostrarDisponibles);
            this.Controls.Add(this.btnActualizarDisponibilidad);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.chkDisponible);
            this.Controls.Add(this.txtBuscarAutor);
            this.Controls.Add(this.txtAnioPublicacion);
            this.Controls.Add(this.txtAutor);
            this.Controls.Add(this.txtTitulo);
            this.Controls.Add(this.lblBuscarAutor);
            this.Controls.Add(this.lblAnioPublicacion);
            this.Controls.Add(this.lblAutor);
            this.Controls.Add(this.lblTitulo);
            this.Name = "FrmLibros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Biblioteca";
            this.Load += new System.EventHandler(this.FrmLibros_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLibros)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.Label lblAnioPublicacion;
        private System.Windows.Forms.Label lblBuscarAutor;
        private System.Windows.Forms.TextBox txtTitulo;
        private System.Windows.Forms.TextBox txtAutor;
        private System.Windows.Forms.TextBox txtAnioPublicacion;
        private System.Windows.Forms.TextBox txtBuscarAutor;
        private System.Windows.Forms.CheckBox chkDisponible;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button btnActualizarDisponibilidad;
        private System.Windows.Forms.Button btnMostrarDisponibles;
        private System.Windows.Forms.Button btnBuscarAutor;
        private System.Windows.Forms.Button btnMostrarTodos;
        private System.Windows.Forms.DataGridView dgvLibros;
    }
}

