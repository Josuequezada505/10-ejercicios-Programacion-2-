﻿using System;
using System.Windows.Forms;

namespace Ejercicio6_Biblioteca
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmLibros());
        }
    }
}