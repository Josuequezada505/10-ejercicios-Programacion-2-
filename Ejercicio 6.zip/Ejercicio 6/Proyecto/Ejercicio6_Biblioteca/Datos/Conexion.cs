﻿using System.Data.SqlClient;

namespace Ejercicio6_Biblioteca.Datos
{
    public class Conexion
    {
        public static string Cadena = @"Data Source=.\MSSQLSERVER1;Initial Catalog=Ejercicio6BibliotecaDB;Integrated Security=True;TrustServerCertificate=True;";
    }
}