﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Ejercicio9_Facturacion
{
    public partial class FrmFacturacion : Form
    {
        private DataTable tablaDetalle;

        private string cadenaConexion = @"Data Source=.\MSSQLSERVER1;Initial Catalog=Ejercicio9FacturacionDB;Integrated Security=True;TrustServerCertificate=True;";

        public FrmFacturacion()
        {
            InitializeComponent();
            InicializarTablaDetalle();
        }

        private void FrmFacturacion_Load(object sender, EventArgs e)
        {
        }

        private void InicializarTablaDetalle()
        {
            tablaDetalle = new DataTable();
            tablaDetalle.Columns.Add("Producto", typeof(string));
            tablaDetalle.Columns.Add("Cantidad", typeof(int));
            tablaDetalle.Columns.Add("Precio", typeof(decimal));
            tablaDetalle.Columns.Add("Subtotal", typeof(decimal));

            dgvDetalleFactura.DataSource = tablaDetalle;
        }

        private void LimpiarDetalle()
        {
            txtProducto.Clear();
            txtCantidad.Clear();
            txtPrecio.Clear();
            txtProducto.Focus();
        }

        private void LimpiarTodo()
        {
            txtCliente.Clear();
            dtpFecha.Value = DateTime.Now;
            LimpiarDetalle();
            tablaDetalle.Clear();
        }

        private bool ValidarDetalle()
        {
            if (string.IsNullOrWhiteSpace(txtProducto.Text))
            {
                MessageBox.Show("Debe ingresar el producto.");
                txtProducto.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtCantidad.Text))
            {
                MessageBox.Show("Debe ingresar la cantidad.");
                txtCantidad.Focus();
                return false;
            }

            if (!int.TryParse(txtCantidad.Text, out int cantidad))
            {
                MessageBox.Show("La cantidad debe ser un número entero.");
                txtCantidad.Focus();
                return false;
            }

            if (cantidad <= 0)
            {
                MessageBox.Show("La cantidad debe ser mayor que cero.");
                txtCantidad.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPrecio.Text))
            {
                MessageBox.Show("Debe ingresar el precio.");
                txtPrecio.Focus();
                return false;
            }

            if (!decimal.TryParse(txtPrecio.Text, out decimal precio))
            {
                MessageBox.Show("El precio debe ser un número válido.");
                txtPrecio.Focus();
                return false;
            }

            if (precio <= 0)
            {
                MessageBox.Show("El precio debe ser mayor que cero.");
                txtPrecio.Focus();
                return false;
            }

            return true;
        }

        private bool ValidarFactura()
        {
            if (string.IsNullOrWhiteSpace(txtCliente.Text))
            {
                MessageBox.Show("Debe ingresar el cliente.");
                txtCliente.Focus();
                return false;
            }

            if (tablaDetalle.Rows.Count == 0)
            {
                MessageBox.Show("Debe agregar al menos un detalle a la factura.");
                txtProducto.Focus();
                return false;
            }

            return true;
        }

        private void btnAgregarDetalle_Click(object sender, EventArgs e)
        {
            if (!ValidarDetalle()) return;

            string producto = txtProducto.Text.Trim();
            int cantidad = int.Parse(txtCantidad.Text);
            decimal precio = decimal.Parse(txtPrecio.Text);
            decimal subtotal = cantidad * precio;

            tablaDetalle.Rows.Add(producto, cantidad, precio, subtotal);

            MessageBox.Show("Detalle agregado correctamente.");

            LimpiarDetalle();
        }

        private void btnEliminarDetalle_Click(object sender, EventArgs e)
        {
            if (dgvDetalleFactura.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar un detalle para eliminar.");
                return;
            }

            if (dgvDetalleFactura.CurrentRow.Index >= 0)
            {
                dgvDetalleFactura.Rows.RemoveAt(dgvDetalleFactura.CurrentRow.Index);
                MessageBox.Show("Detalle eliminado correctamente.");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarDetalle();
        }

        private void btnRegistrarFactura_Click(object sender, EventArgs e)
        {
            if (!ValidarFactura()) return;

            using (SqlConnection conexion = new SqlConnection(cadenaConexion))
            {
                conexion.Open();

                SqlTransaction transaccion = conexion.BeginTransaction();

                try
                {
                    string queryFactura = "INSERT INTO Facturas (Cliente, Fecha) OUTPUT INSERTED.Id VALUES (@Cliente, @Fecha)";

                    SqlCommand comandoFactura = new SqlCommand(queryFactura, conexion, transaccion);
                    comandoFactura.Parameters.AddWithValue("@Cliente", txtCliente.Text.Trim());
                    comandoFactura.Parameters.AddWithValue("@Fecha", dtpFecha.Value);

                    int facturaId = Convert.ToInt32(comandoFactura.ExecuteScalar());

                    foreach (DataRow fila in tablaDetalle.Rows)
                    {
                        string queryDetalle = "INSERT INTO DetalleFactura (FacturaId, Producto, Cantidad, Precio) VALUES (@FacturaId, @Producto, @Cantidad, @Precio)";

                        SqlCommand comandoDetalle = new SqlCommand(queryDetalle, conexion, transaccion);
                        comandoDetalle.Parameters.AddWithValue("@FacturaId", facturaId);
                        comandoDetalle.Parameters.AddWithValue("@Producto", fila["Producto"].ToString());
                        comandoDetalle.Parameters.AddWithValue("@Cantidad", Convert.ToInt32(fila["Cantidad"]));
                        comandoDetalle.Parameters.AddWithValue("@Precio", Convert.ToDecimal(fila["Precio"]));

                        comandoDetalle.ExecuteNonQuery();
                    }

                    transaccion.Commit();

                    MessageBox.Show("Factura registrada correctamente. La transacción fue confirmada con Commit.");

                    LimpiarTodo();
                    CargarFacturas();
                }
                catch (Exception ex)
                {
                    transaccion.Rollback();

                    MessageBox.Show("Ocurrió un error al registrar la factura. La transacción fue revertida con Rollback.\n\nError: " + ex.Message);
                }
            }
        }

        private void btnMostrarFacturas_Click(object sender, EventArgs e)
        {
            CargarFacturas();
        }

        private void CargarFacturas()
        {
            using (SqlConnection conexion = new SqlConnection(cadenaConexion))
            {
                string query = @"
                    SELECT 
                        F.Id,
                        F.Cliente,
                        F.Fecha,
                        SUM(D.Cantidad * D.Precio) AS Total
                    FROM Facturas F
                    INNER JOIN DetalleFactura D ON F.Id = D.FacturaId
                    GROUP BY F.Id, F.Cliente, F.Fecha
                    ORDER BY F.Id DESC";

                SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion);
                DataTable tablaFacturas = new DataTable();

                adaptador.Fill(tablaFacturas);

                dgvFacturas.DataSource = tablaFacturas;
            }
        }
    }
}