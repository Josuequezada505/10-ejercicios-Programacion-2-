﻿using System;
using System.Windows.Forms;

namespace Ejercicio9_Facturacion
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmFacturacion());
        }
    }
}