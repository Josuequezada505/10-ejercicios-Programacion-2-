CREATE DATABASE Ejercicio9FacturacionDB;
GO

USE Ejercicio9FacturacionDB;
GO

CREATE TABLE Facturas
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Cliente NVARCHAR(100) NOT NULL,
    Fecha DATETIME NOT NULL
);
GO

CREATE TABLE DetalleFactura
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    FacturaId INT NOT NULL,
    Producto NVARCHAR(100) NOT NULL,
    Cantidad INT NOT NULL,
    Precio DECIMAL(18,2) NOT NULL,
    CONSTRAINT FK_DetalleFactura_Facturas
    FOREIGN KEY (FacturaId) REFERENCES Facturas(Id)
);
GO