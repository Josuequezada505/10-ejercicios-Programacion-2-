﻿using System;
using System.Windows.Forms;
using Ejercicio4_Empleados.Entidades;
using Ejercicio4_Empleados.Repositorio;

namespace Ejercicio4_Empleados
{
    public partial class FrmEmpleados : Form
    {
        private readonly IEmpleadoRepository _repositorio;

        public FrmEmpleados()
        {
            InitializeComponent();
            _repositorio = new EmpleadoRepository();
        }

        private void FrmEmpleados_Load(object sender, EventArgs e)
        {
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtCargo.Clear();
            txtSalario.Clear();
            txtNombre.Focus();
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Debe ingresar el nombre del empleado.");
                txtNombre.Focus();
                return false;
            }

            foreach (char letra in txtNombre.Text)
            {
                if (!char.IsLetter(letra) && !char.IsWhiteSpace(letra))
                {
                    MessageBox.Show("El nombre solo debe contener letras.");
                    txtNombre.Focus();
                    return false;
                }
            }

            if (string.IsNullOrWhiteSpace(txtCargo.Text))
            {
                MessageBox.Show("Debe ingresar el cargo del empleado.");
                txtCargo.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtSalario.Text))
            {
                MessageBox.Show("Debe ingresar el salario del empleado.");
                txtSalario.Focus();
                return false;
            }

            if (!decimal.TryParse(txtSalario.Text, out decimal salario))
            {
                MessageBox.Show("El salario debe ser un número válido.");
                txtSalario.Focus();
                return false;
            }

            if (salario < 0)
            {
                MessageBox.Show("El salario no puede ser negativo.");
                txtSalario.Focus();
                return false;
            }

            return true;
        }

        private void CargarEmpleados()
        {
            dgvEmpleados.DataSource = null;
            dgvEmpleados.DataSource = _repositorio.MostrarTodos();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;

            Empleado empleado = new Empleado
            {
                Nombre = txtNombre.Text.Trim(),
                Cargo = txtCargo.Text.Trim(),
                Salario = decimal.Parse(txtSalario.Text)
            };

            _repositorio.Guardar(empleado);

            MessageBox.Show("Empleado guardado correctamente.");

            CargarEmpleados();
            LimpiarCampos();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (dgvEmpleados.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar un empleado para actualizar.");
                return;
            }

            if (dgvEmpleados.CurrentRow.Cells["Id"].Value == null)
            {
                MessageBox.Show("Debe seleccionar un empleado válido.");
                return;
            }

            if (!ValidarCampos()) return;

            int id = Convert.ToInt32(dgvEmpleados.CurrentRow.Cells["Id"].Value);

            Empleado empleado = new Empleado
            {
                Id = id,
                Nombre = txtNombre.Text.Trim(),
                Cargo = txtCargo.Text.Trim(),
                Salario = decimal.Parse(txtSalario.Text)
            };

            _repositorio.Actualizar(empleado);

            MessageBox.Show("Empleado actualizado correctamente.");

            CargarEmpleados();
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvEmpleados.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar un empleado para eliminar.");
                return;
            }

            if (dgvEmpleados.CurrentRow.Cells["Id"].Value == null)
            {
                MessageBox.Show("Debe seleccionar un empleado válido.");
                return;
            }

            int id = Convert.ToInt32(dgvEmpleados.CurrentRow.Cells["Id"].Value);

            DialogResult respuesta = MessageBox.Show(
                "¿Está seguro que desea eliminar este empleado?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta == DialogResult.Yes)
            {
                _repositorio.Eliminar(id);
                MessageBox.Show("Empleado eliminado correctamente.");
                CargarEmpleados();
                LimpiarCampos();
            }
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            CargarEmpleados();
        }

        private void btnTotalSalarios_Click(object sender, EventArgs e)
        {
            decimal total = _repositorio.ObtenerTotalSalarios();
            MessageBox.Show("El total de salarios pagados es: C$ " + total.ToString("N2"));
        }

        private void btnSalarioMayor_Click(object sender, EventArgs e)
        {
            Empleado empleado = _repositorio.ObtenerEmpleadoSalarioMayor();

            if (empleado == null)
            {
                MessageBox.Show("No hay empleados registrados.");
                return;
            }

            MessageBox.Show(
                "Empleado con salario más alto:\n\n" +
                "Nombre: " + empleado.Nombre + "\n" +
                "Cargo: " + empleado.Cargo + "\n" +
                "Salario: C$ " + empleado.Salario.ToString("N2")
            );
        }

        private void dgvEmpleados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvEmpleados.Rows[e.RowIndex];

                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtCargo.Text = fila.Cells["Cargo"].Value.ToString();
                txtSalario.Text = fila.Cells["Salario"].Value.ToString();
            }
        }
    }
}