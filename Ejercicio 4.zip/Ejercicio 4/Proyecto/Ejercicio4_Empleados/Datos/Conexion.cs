﻿using System.Data.SqlClient;

namespace Ejercicio4_Empleados.Datos
{
    public class Conexion
    {
        public static string Cadena = @"Data Source=.\MSSQLSERVER1;Initial Catalog=Ejercicio4EmpleadosDB;Integrated Security=True;TrustServerCertificate=True;";
    }
}