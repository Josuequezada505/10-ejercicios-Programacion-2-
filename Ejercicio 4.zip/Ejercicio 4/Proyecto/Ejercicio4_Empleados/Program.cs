﻿using System;
using System.Windows.Forms;

namespace Ejercicio4_Empleados
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmEmpleados());
        }
    }
}