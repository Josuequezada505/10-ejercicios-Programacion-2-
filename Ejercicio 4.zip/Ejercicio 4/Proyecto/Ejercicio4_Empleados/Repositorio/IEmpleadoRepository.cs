﻿using System.Collections.Generic;
using Ejercicio4_Empleados.Entidades;

namespace Ejercicio4_Empleados.Repositorio
{
    public interface IEmpleadoRepository
    {
        void Guardar(Empleado empleado);
        void Actualizar(Empleado empleado);
        void Eliminar(int id);
        List<Empleado> MostrarTodos();
        decimal ObtenerTotalSalarios();
        Empleado ObtenerEmpleadoSalarioMayor();
    }
}