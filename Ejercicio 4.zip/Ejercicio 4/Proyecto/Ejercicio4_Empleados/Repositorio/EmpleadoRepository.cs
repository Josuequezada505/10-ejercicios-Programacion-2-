﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Ejercicio4_Empleados.Datos;
using Ejercicio4_Empleados.Entidades;

namespace Ejercicio4_Empleados.Repositorio
{
    public class EmpleadoRepository : IEmpleadoRepository
    {
        public void Guardar(Empleado empleado)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "INSERT INTO Empleados (Nombre, Cargo, Salario) VALUES (@Nombre, @Cargo, @Salario)";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Nombre", empleado.Nombre);
                comando.Parameters.AddWithValue("@Cargo", empleado.Cargo);
                comando.Parameters.AddWithValue("@Salario", empleado.Salario);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public void Actualizar(Empleado empleado)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "UPDATE Empleados SET Nombre = @Nombre, Cargo = @Cargo, Salario = @Salario WHERE Id = @Id";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", empleado.Id);
                comando.Parameters.AddWithValue("@Nombre", empleado.Nombre);
                comando.Parameters.AddWithValue("@Cargo", empleado.Cargo);
                comando.Parameters.AddWithValue("@Salario", empleado.Salario);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public void Eliminar(int id)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "DELETE FROM Empleados WHERE Id = @Id";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", id);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public List<Empleado> MostrarTodos()
        {
            List<Empleado> lista = new List<Empleado>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Nombre, Cargo, Salario FROM Empleados";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Empleado
                    {
                        Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        Cargo = reader["Cargo"].ToString(),
                        Salario = (decimal)reader["Salario"]
                    });
                }
            }

            return lista;
        }

        public decimal ObtenerTotalSalarios()
        {
            decimal total = 0;

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT ISNULL(SUM(Salario), 0) FROM Empleados";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                total = (decimal)comando.ExecuteScalar();
            }

            return total;
        }

        public Empleado ObtenerEmpleadoSalarioMayor()
        {
            Empleado empleado = null;

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT TOP 1 Id, Nombre, Cargo, Salario FROM Empleados ORDER BY Salario DESC";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                if (reader.Read())
                {
                    empleado = new Empleado
                    {
                        Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        Cargo = reader["Cargo"].ToString(),
                        Salario = (decimal)reader["Salario"]
                    };
                }
            }

            return empleado;
        }
    }
}