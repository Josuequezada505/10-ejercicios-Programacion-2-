﻿namespace Ejercicio4_Empleados.Entidades
{
    public class Empleado
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Cargo { get; set; }
        public decimal Salario { get; set; }
    }
}