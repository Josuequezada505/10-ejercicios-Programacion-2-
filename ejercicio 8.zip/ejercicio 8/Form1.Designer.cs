﻿namespace ejercicio8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNombre = new TextBox();
            txtDiagnostico = new TextBox();
            txtEdad = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnGuardar = new Button();
            dgvPacientes = new DataGridView();
            btnBuscarNombre = new TextBox();
            txtBuscarNombre = new Button();
            button1 = new Button();
            btnFiltroMayores = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPacientes).BeginInit();
            SuspendLayout();
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(125, 33);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(100, 23);
            txtNombre.TabIndex = 0;
            // 
            // txtDiagnostico
            // 
            txtDiagnostico.Location = new Point(125, 113);
            txtDiagnostico.Name = "txtDiagnostico";
            txtDiagnostico.Size = new Size(100, 23);
            txtDiagnostico.TabIndex = 1;
            // 
            // txtEdad
            // 
            txtEdad.Location = new Point(125, 74);
            txtEdad.Name = "txtEdad";
            txtEdad.Size = new Size(100, 23);
            txtEdad.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(31, 41);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 3;
            label1.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 82);
            label2.Name = "label2";
            label2.Size = new Size(33, 15);
            label2.TabIndex = 4;
            label2.Text = "Edad";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(31, 121);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 5;
            label3.Text = "Diagnostico";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(31, 157);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(194, 29);
            btnGuardar.TabIndex = 6;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // dgvPacientes
            // 
            dgvPacientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPacientes.Location = new Point(301, 54);
            dgvPacientes.Name = "dgvPacientes";
            dgvPacientes.Size = new Size(332, 253);
            dgvPacientes.TabIndex = 7;
            // 
            // btnBuscarNombre
            // 
            btnBuscarNombre.Location = new Point(424, 25);
            btnBuscarNombre.Name = "btnBuscarNombre";
            btnBuscarNombre.Size = new Size(209, 23);
            btnBuscarNombre.TabIndex = 8;
            // 
            // txtBuscarNombre
            // 
            txtBuscarNombre.Location = new Point(299, 25);
            txtBuscarNombre.Name = "txtBuscarNombre";
            txtBuscarNombre.Size = new Size(119, 23);
            txtBuscarNombre.TabIndex = 9;
            txtBuscarNombre.Text = "Buscar por nombre";
            txtBuscarNombre.UseVisualStyleBackColor = true;
            txtBuscarNombre.Click += btnBuscar_Click;
            // 
            // button1
            // 
            button1.Location = new Point(31, 227);
            button1.Name = "button1";
            button1.Size = new Size(194, 29);
            button1.TabIndex = 10;
            button1.Text = "Mostrar todo";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnMostrarTodo_Click;
            // 
            // btnFiltroMayores
            // 
            btnFiltroMayores.Location = new Point(31, 192);
            btnFiltroMayores.Name = "btnFiltroMayores";
            btnFiltroMayores.Size = new Size(194, 29);
            btnFiltroMayores.TabIndex = 11;
            btnFiltroMayores.Text = "Mayores de 60 años";
            btnFiltroMayores.UseVisualStyleBackColor = true;
            btnFiltroMayores.Click += btnFiltroMayores_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnFiltroMayores);
            Controls.Add(button1);
            Controls.Add(txtBuscarNombre);
            Controls.Add(btnBuscarNombre);
            Controls.Add(dgvPacientes);
            Controls.Add(btnGuardar);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtEdad);
            Controls.Add(txtDiagnostico);
            Controls.Add(txtNombre);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvPacientes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNombre;
        private TextBox txtDiagnostico;
        private TextBox txtEdad;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnGuardar;
        private DataGridView dgvPaciehte;
        private TextBox btnBuscarNombre;
        private DataGridView dgvPacientes;
        private Button txtBuscarNombre;
        private Button button1;
        private Button btnFiltroMayores;
    }
}
