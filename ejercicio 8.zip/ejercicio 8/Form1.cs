using Ejercicio_8.Entidades;
using Ejercicio8.Repositorios;
using System;
using System.Windows.Forms;

namespace ejercicio8
{
    public partial class Form1 : Form
    {
   
        private PacienteRepository _repo = new PacienteRepository();

        public Form1()
        {
            InitializeComponent();
        }


        private void ActualizarGrid()
        {
            dgvPacientes.DataSource = null;
            dgvPacientes.DataSource = _repo.ObtenerTodos();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            ActualizarGrid();
        }

        

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                var nuevoPaciente = new Paciente
                {
                    Nombre = txtNombre.Text,
                    Edad = int.Parse(txtEdad.Text),
                    Diagnostico = txtDiagnostico.Text
                };

                _repo.AgregarPaciente(nuevoPaciente);

                txtNombre.Clear();
                txtEdad.Clear();
                txtDiagnostico.Clear();

                ActualizarGrid();
                MessageBox.Show("¡Paciente registrado exitosamente!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error. Revisa que la edad sea un número válido. Error: " + ex.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            dgvPacientes.DataSource = null;
            dgvPacientes.DataSource = _repo.BuscarPorNombre(txtBuscarNombre.Text.Trim());
        }

        private void btnFiltroMayores_Click(object sender, EventArgs e)
        {
            dgvPacientes.DataSource = null;
            dgvPacientes.DataSource = _repo.ObtenerMayoresDe60();
        }

        private void btnMostrarTodo_Click(object sender, EventArgs e)
        {
            ActualizarGrid();
          
        }
    }
}   