﻿using Ejercicio_8.Entidades;
using Ejercicio8.Datos;
using System.Collections.Generic;
using System.Linq;

namespace Ejercicio8.Repositorios
{
    public class PacienteRepository
    {
        private AppDbContext _context;

        public PacienteRepository()
        {
            _context = new AppDbContext();
        }

     
        public void AgregarPaciente(Paciente paciente)
        {
            _context.Pacientes.Add(paciente);
            _context.SaveChanges();
        }

 
        public List<Paciente> ObtenerTodos()
        {
            return _context.Pacientes.ToList();
        }

     
        public List<Paciente> BuscarPorNombre(string nombreBusqueda)
        {
    
            return _context.Pacientes
                           .Where(p => p.Nombre.Contains(nombreBusqueda))
                           .ToList();
        }


        public List<Paciente> ObtenerMayoresDe60()
        {
            return _context.Pacientes
                           .Where(p => p.Edad > 60)
                           .ToList();
        }
    }
}