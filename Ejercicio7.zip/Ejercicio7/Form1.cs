using System;
using System.Windows.Forms;

using Ejercicio7.Entidades;
using Ejercicio7.Repositorios;

namespace Ejercicio7
{
    public partial class Form1 : Form
    {

        private VentaRepository _repo;

        public Form1()
        {
            InitializeComponent();
            _repo = new VentaRepository();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {

                var nuevaVenta = new Venta
                {
                    Cliente = txtCliente.Text,
                    Producto = txtProducto.Text,
                    Cantidad = int.Parse(txtCantidad.Text),
                    Precio = decimal.Parse(txtPrecio.Text)
                };


                _repo.AgregarVenta(nuevaVenta);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = _repo.ObtenerTodas();


                lblTotalVentaActual.Text = "Total Venta Actual: $" + nuevaVenta.TotalVenta.ToString("0.00");
                lblTotalGeneral.Text = "Total General: $" + _repo.ObtenerTotalGeneralVendido().ToString("0.00");
                lblProductoTop.Text = "Producto Top: " + _repo.ObtenerProductoMasVendido();


                txtCliente.Clear();
                txtProducto.Clear();
                txtCantidad.Clear();
                txtPrecio.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error, revisa que los números estén bien escritos. Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                var nuevaVenta = new Venta
                {
                    Cliente = txtCliente.Text,
                    Producto = txtProducto.Text,
                    Cantidad = int.Parse(txtCantidad.Text),
                    Precio = decimal.Parse(txtPrecio.Text)
                };


                _repo.AgregarVenta(nuevaVenta);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = _repo.ObtenerTodas();


                lblTotalVentaActual.Text = "Total Venta Actual: $" + nuevaVenta.TotalVenta.ToString("0.00");
                lblTotalGeneral.Text = "Total General: $" + _repo.ObtenerTotalGeneralVendido().ToString("0.00");
                lblProductoTop.Text = "Producto Top: " + _repo.ObtenerProductoMasVendido();


                txtCliente.Clear();
                txtProducto.Clear();
                txtCantidad.Clear();
                txtPrecio.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hubo un error, revisa que los números estén bien escritos. Error: " + ex.Message);
            }
        }
    }
}