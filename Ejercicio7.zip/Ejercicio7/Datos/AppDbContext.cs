﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Ejercicio7.Entidades;

namespace Ejercicio7.Datos
{
    public class AppDbContext : DbContext
    {
        public DbSet<Venta> Ventas { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
             
            optionsBuilder.UseSqlServer("Server=DESKTOP-18RBHEM\\SQLEXPRESS;Database=VentasDB;Integrated Security=True;TrustServerCertificate=True;");
        }
    }
}