﻿using System.Collections.Generic;
using System.Linq;
using Ejercicio7.Datos;
using Ejercicio7.Entidades;

namespace Ejercicio7.Repositorios
{
    public class VentaRepository
    {
        private readonly AppDbContext _context;

        public VentaRepository()
        {
            _context = new AppDbContext();
        }

        public void AgregarVenta(Venta venta)
        {
            _context.Ventas.Add(venta);
            _context.SaveChanges();
        }

        public List<Venta> ObtenerTodas()
        {
            return _context.Ventas.ToList();
        }


        public decimal ObtenerTotalGeneralVendido()
        {
            return _context.Ventas.Sum(v => v.Cantidad * v.Precio);
        }


        public string ObtenerProductoMasVendido()
        {
            var producto = _context.Ventas
                .GroupBy(v => v.Producto)
                .OrderByDescending(g => g.Sum(v => v.Cantidad))
                .Select(g => g.Key)
                .FirstOrDefault();

            return producto ?? "No hay ventas aún";
        }
    }
}