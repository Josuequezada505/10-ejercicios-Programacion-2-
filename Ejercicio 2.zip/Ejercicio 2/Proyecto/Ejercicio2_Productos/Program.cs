﻿using System;
using System.Windows.Forms;

namespace Ejercicio2_Productos
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmProductos());
        }
    }
}