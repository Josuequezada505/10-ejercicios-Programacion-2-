﻿using System;
using System.Windows.Forms;
using Ejercicio2_Productos.Entidades;
using Ejercicio2_Productos.Repositorio;

namespace Ejercicio2_Productos
{
    public partial class FrmProductos : Form
    {
        private readonly IProductoRepository _repositorio;

        public FrmProductos()
        {
            InitializeComponent();
            _repositorio = new ProductoRepository();
        }

        private void FrmProductos_Load(object sender, EventArgs e)
        {
            // Este método queda vacío.
            // Se agrega porque el diseñador lo puede estar llamando.
        }

        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtPrecio.Clear();
            txtStock.Clear();
            txtBuscar.Clear();
            txtNombre.Focus();
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Debe ingresar el nombre del producto.");
                txtNombre.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPrecio.Text))
            {
                MessageBox.Show("Debe ingresar el precio del producto.");
                txtPrecio.Focus();
                return false;
            }

            if (!decimal.TryParse(txtPrecio.Text, out decimal precio))
            {
                MessageBox.Show("El precio debe ser un número válido.");
                txtPrecio.Focus();
                return false;
            }

            if (precio < 0)
            {
                MessageBox.Show("El precio no puede ser negativo.");
                txtPrecio.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtStock.Text))
            {
                MessageBox.Show("Debe ingresar el stock del producto.");
                txtStock.Focus();
                return false;
            }

            if (!int.TryParse(txtStock.Text, out int stock))
            {
                MessageBox.Show("El stock debe ser un número entero.");
                txtStock.Focus();
                return false;
            }

            if (stock < 0)
            {
                MessageBox.Show("El stock no puede ser negativo.");
                txtStock.Focus();
                return false;
            }

            return true;
        }

        private void CargarProductos()
        {
            dgvProductos.DataSource = null;
            dgvProductos.DataSource = _repositorio.MostrarTodos();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                return;
            }

            Producto producto = new Producto
            {
                Nombre = txtNombre.Text.Trim(),
                Precio = decimal.Parse(txtPrecio.Text),
                Stock = int.Parse(txtStock.Text)
            };

            _repositorio.Insertar(producto);

            MessageBox.Show("Producto insertado correctamente.");

            CargarProductos();
            LimpiarCampos();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.CurrentRow == null)
            {
                MessageBox.Show("Debe seleccionar un producto para actualizar.");
                return;
            }

            if (dgvProductos.CurrentRow.Cells["Id"].Value == null)
            {
                MessageBox.Show("Debe seleccionar un producto válido.");
                return;
            }

            if (!ValidarCampos())
            {
                return;
            }

            int id = Convert.ToInt32(dgvProductos.CurrentRow.Cells["Id"].Value);

            Producto producto = new Producto
            {
                Id = id,
                Nombre = txtNombre.Text.Trim(),
                Precio = decimal.Parse(txtPrecio.Text),
                Stock = int.Parse(txtStock.Text)
            };

            _repositorio.Actualizar(producto);

            MessageBox.Show("Producto actualizado correctamente.");

            CargarProductos();
            LimpiarCampos();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBuscar.Text))
            {
                MessageBox.Show("Debe ingresar el nombre del producto a buscar.");
                txtBuscar.Focus();
                return;
            }

            dgvProductos.DataSource = null;
            dgvProductos.DataSource = _repositorio.BuscarPorNombre(txtBuscar.Text.Trim());
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            CargarProductos();
        }

        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvProductos.Rows[e.RowIndex];

                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtPrecio.Text = fila.Cells["Precio"].Value.ToString();
                txtStock.Text = fila.Cells["Stock"].Value.ToString();
            }
        }
    }
}