﻿using System.Collections.Generic;
using Ejercicio2_Productos.Entidades;

namespace Ejercicio2_Productos.Repositorio
{
    public interface IProductoRepository
    {
        void Insertar(Producto producto);
        void Actualizar(Producto producto);
        List<Producto> MostrarTodos();
        List<Producto> BuscarPorNombre(string nombre);
    }
}