﻿using System.Collections.Generic;
using System.Data.SqlClient;
using Ejercicio2_Productos.Datos;
using Ejercicio2_Productos.Entidades;

namespace Ejercicio2_Productos.Repositorio
{
    public class ProductoRepository : IProductoRepository
    {
        public void Insertar(Producto producto)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "INSERT INTO Productos (Nombre, Precio, Stock) VALUES (@Nombre, @Precio, @Stock)";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Nombre", producto.Nombre);
                comando.Parameters.AddWithValue("@Precio", producto.Precio);
                comando.Parameters.AddWithValue("@Stock", producto.Stock);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public void Actualizar(Producto producto)
        {
            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "UPDATE Productos SET Nombre = @Nombre, Precio = @Precio, Stock = @Stock WHERE Id = @Id";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Id", producto.Id);
                comando.Parameters.AddWithValue("@Nombre", producto.Nombre);
                comando.Parameters.AddWithValue("@Precio", producto.Precio);
                comando.Parameters.AddWithValue("@Stock", producto.Stock);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
        }

        public List<Producto> MostrarTodos()
        {
            List<Producto> lista = new List<Producto>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Nombre, Precio, Stock FROM Productos";

                SqlCommand comando = new SqlCommand(query, conexion);

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Producto
                    {
                        Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        Precio = (decimal)reader["Precio"],
                        Stock = (int)reader["Stock"]
                    });
                }
            }

            return lista;
        }

        public List<Producto> BuscarPorNombre(string nombre)
        {
            List<Producto> lista = new List<Producto>();

            using (SqlConnection conexion = new SqlConnection(Conexion.Cadena))
            {
                string query = "SELECT Id, Nombre, Precio, Stock FROM Productos WHERE Nombre LIKE @Nombre";

                SqlCommand comando = new SqlCommand(query, conexion);
                comando.Parameters.AddWithValue("@Nombre", "%" + nombre + "%");

                conexion.Open();
                SqlDataReader reader = comando.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Producto
                    {
                        Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        Precio = (decimal)reader["Precio"],
                        Stock = (int)reader["Stock"]
                    });
                }
            }

            return lista;
        }
    }
}