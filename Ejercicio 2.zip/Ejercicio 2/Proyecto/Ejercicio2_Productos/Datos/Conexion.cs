﻿using System.Data.SqlClient;

namespace Ejercicio2_Productos.Datos
{
    public class Conexion
    {
        public static string Cadena = @"Data Source=.\MSSQLSERVER1;Initial Catalog=Ejercicio2ProductosDB;Integrated Security=True;TrustServerCertificate=True;";
    }
}